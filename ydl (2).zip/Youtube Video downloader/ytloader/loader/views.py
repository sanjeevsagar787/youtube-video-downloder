from django.shortcuts import render, redirect
# pytub package for download youtube video
from pytube import YouTube
import os

url = ''


def ytb_down(request):
    return render(request, 'ytb_main.html')


def yt_download(request):
    global url
    url = request.GET.get('url')
    # created object for know which video download ..
    obj = YouTube(url)
    resolutions = []
    strm_all = obj.streams.filter(progressive=True).all()
    for i in strm_all:
        resolutions.append(i.resolution)
        resolutions = list(dict.fromkeys(resolutions))
        embed_link = url.replace("watch?v=", "embed/")
    return render(request, 'yt_download.html', {'rsl': resolutions, 'embd': embed_link, 'url': url})



def download_complete(request, res):
    global url
    homedir = os.path.expanduser("~")
    dirs = homedir + '/Downloads'
    print(f'DIRECT :', f'{dirs}/Downloads')
    if request.method == "POST":
        YouTube(url).streams.get_by_resolution(
            res).download(homedir + '/Downloads')
        return render(request, 'download_complete.html')
    else:
        return render(request, 'sorry.html')
