from django.apps import AppConfig


class LoaderConfig(AppConfig):
    name = 'loader'
